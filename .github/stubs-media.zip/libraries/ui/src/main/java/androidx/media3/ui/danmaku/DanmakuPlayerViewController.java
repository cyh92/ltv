package androidx.media3.ui.danmaku;

import android.net.Uri;

import androidx.annotation.Nullable;
import androidx.media3.common.Player;
import androidx.media3.ui.PlayerView;
import androidx.media3.ui.R;
import androidx.media3.ui.danmaku.fetcher.BiliFetcher;
import androidx.media3.ui.danmaku.fetcher.Fetcher;
import androidx.media3.ui.danmaku.fetcher.IQIYIFetcher;
import androidx.media3.ui.danmaku.fetcher.MGTVFetcher;
import androidx.media3.ui.danmaku.fetcher.QQFetcher;
import androidx.media3.ui.danmaku.fetcher.YoukuFetcher;
import androidx.media3.ui.danmaku.parser.BiliParser;
import androidx.media3.ui.danmaku.parser.IQIYIParser;
import androidx.media3.ui.danmaku.parser.MGTVParser;
import androidx.media3.ui.danmaku.parser.Parser;
import androidx.media3.ui.danmaku.parser.QQParser;
import androidx.media3.ui.danmaku.parser.TxtParser;
import androidx.media3.ui.danmaku.parser.YoukuParser;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import okhttp3.OkHttpClient;

/**
 * 0.1.107：真实现（原为 stubs-media.zip 里的空壳）。
 *
 * <p>弹幕的渲染（DanmakuView）、加载（DanmakuController + Fetcher/Parser）全在
 * FongMi/media 的 ui_danmaku 模块里是真的，这里只做胶水：复用 PlayerView 布局里已有的
 * DanmakuView（R.id.exo_danmaku），把 app 的调用转给一个 DanmakuController。
 * PlayerView 内部自己也有一个 DanmakuController，但它是 private 且 PlayerView 没有任何
 * 公开的弹幕方法，所以内部那个永远拿不到数据源、是死的；这里自建一个控制器驱动同一个 view。
 *
 * <p>另外包一层记录型 Fetcher/Parser，让 getItems() 能返回已加载的弹幕列表
 * （供 PlaybackContentPanel 的弹幕列表用）。渲染走控制器自己的分段加载，
 * 记录只旁听、不重复请求、不改变加载行为。
 */
public final class DanmakuPlayerViewController {

  private final DanmakuController controller = new DanmakuController();
  private final List<Danmaku> loadedItems = Collections.synchronizedList(new ArrayList<>());

  @Nullable private PlayerView playerView;
  @Nullable private Uri currentUri;

  public DanmakuPlayerViewController() {
    controller.registerFetcher(new RecordingFetcher(BiliFetcher.INSTANCE));
    controller.registerFetcher(new RecordingFetcher(IQIYIFetcher.INSTANCE));
    controller.registerFetcher(new RecordingFetcher(MGTVFetcher.INSTANCE));
    controller.registerFetcher(new RecordingFetcher(QQFetcher.INSTANCE));
    controller.registerFetcher(new RecordingFetcher(YoukuFetcher.INSTANCE));
    controller.registerParser(new RecordingParser(BiliParser.INSTANCE));
    controller.registerParser(new RecordingParser(TxtParser.INSTANCE));
    controller.registerParser(new RecordingParser(QQParser.INSTANCE));
    controller.registerParser(new RecordingParser(YoukuParser.INSTANCE));
    controller.registerParser(new RecordingParser(MGTVParser.INSTANCE));
    controller.registerParser(new RecordingParser(IQIYIParser.INSTANCE));
  }

  public void bind(PlayerView playerView) {
    this.playerView = playerView;
    DanmakuView view = playerView.findViewById(R.id.exo_danmaku);
    controller.setView(view);
    syncPlayer();
  }

  public void setConfig(DanmakuConfig config) {
    controller.setConfig(config);
  }

  public void setOkHttpClient(OkHttpClient client) {
    controller.setOkHttpClient(client);
  }

  public void setEnabled(boolean enabled) {
    controller.setEnabled(enabled);
    syncPlayer();
  }

  public void setDataSource(@Nullable Uri uri) {
    if (uri == null) {
      loadedItems.clear();
      currentUri = null;
    } else if (!uri.equals(currentUri)) {
      loadedItems.clear();
      currentUri = uri;
    }
    controller.setDataSource(uri);
    syncPlayer();
  }

  public void sendNow(String text) {
    controller.sendNow(text);
  }

  public void post(Danmaku danmaku) {
    controller.sendNow(danmaku);
    loadedItems.add(danmaku);
  }

  public List<Danmaku> getItems() {
    List<Danmaku> copy;
    synchronized (loadedItems) {
      copy = new ArrayList<>(loadedItems);
    }
    copy.sort(Danmaku.BY_TIME);
    return Collections.unmodifiableList(copy);
  }

  public void close() {
    controller.release();
    loadedItems.clear();
    currentUri = null;
    playerView = null;
  }

  /** PlayerView 上的 player 可能在 bind 之后才挂上，关键调用时重新同步一次。 */
  private void syncPlayer() {
    if (playerView == null) return;
    Player player = playerView.getPlayer();
    controller.setPlayer(player);
  }

  private void record(List<Danmaku> items) {
    if (items != null && !items.isEmpty()) loadedItems.addAll(items);
  }

  /** 只旁听：把 accepts/prepare 原样委托，fetchSegment 拿到数据后记一份。 */
  private final class RecordingFetcher implements Fetcher {

    private final Fetcher delegate;

    RecordingFetcher(Fetcher delegate) {
      this.delegate = delegate;
    }

    @Override
    public boolean accepts(Uri uri) {
      return delegate.accepts(uri);
    }

    @Override
    public Session prepare(Uri uri, OkHttpClient client, long durationMs) throws IOException {
      return new RecordingSession(delegate.prepare(uri, client, durationMs));
    }

    private final class RecordingSession implements Session {

      private final Session delegate;

      RecordingSession(Session delegate) {
        this.delegate = delegate;
      }

      @Override
      public int segmentCount() {
        return delegate.segmentCount();
      }

      @Override
      public int segmentDurationMs() {
        return delegate.segmentDurationMs();
      }

      @Override
      public List<Danmaku> fetchSegment(int segmentNumber) throws IOException {
        List<Danmaku> items = delegate.fetchSegment(segmentNumber);
        record(items);
        return items;
      }

      @Override
      public void release() {
        delegate.release();
      }
    }
  }

  /** 只旁听：把 sniff/parse 原样委托，parse 拿到数据后记一份。 */
  private final class RecordingParser implements Parser {

    private final Parser delegate;

    RecordingParser(Parser delegate) {
      this.delegate = delegate;
    }

    @Override
    public boolean sniff(InputStream inputStream, int sniffLength) throws IOException {
      return delegate.sniff(inputStream, sniffLength);
    }

    @Override
    public List<Danmaku> parse(InputStream inputStream) throws IOException {
      List<Danmaku> items = delegate.parse(inputStream);
      record(items);
      return items;
    }
  }
}
