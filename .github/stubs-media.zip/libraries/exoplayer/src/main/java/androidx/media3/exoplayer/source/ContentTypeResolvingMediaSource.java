package androidx.media3.exoplayer.source;

import android.net.Uri;
import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.common.util.Util;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DataSpec;
import androidx.media3.exoplayer.drm.DrmSessionManagerProvider;
import androidx.media3.exoplayer.upstream.LoadErrorHandlingPolicy;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Map;

/**
 * Real content-type resolution for a MediaItem whose MIME type is not set and
 * whose URI has no recognizable extension.
 *
 * <p>Why this exists: FongMi/media release-1.11.0-fongmi (the media3 version this
 * app builds from source) does NOT contain ContentTypeResolvingMediaSource at
 * all, so the build ships a pass-through stub that just delegates to
 * DefaultMediaSourceFactory without resolving anything. DefaultMediaSourceFactory
 * then infers the type from the URI extension only (Util.inferContentType): a
 * play URL with no extension (a local-proxy URL such as
 * http://127.0.0.1:PORT/proxy?do=... , or a bare query URL serving an m3u8
 * playlist) is guessed as progressive, the m3u8 text matches no extractor, and
 * playback fails with PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED
 * ("Container Unsupported"). Stock FongMi / OK影视+ use a real
 * implementation, so the same URL plays there.
 *
 * <p>This implementation resolves the type only when it is actually unknown
 * (no MIME type set AND the URI extension reveals nothing), by opening the URI
 * once with the supplied DataSource.Factory and inspecting the response
 * Content-Type, falling back to sniffing the first bytes for an HLS (#EXTM3U)
 * or DASH (&lt;MPD) marker. The resolved MIME type is set on a copy of the
 * MediaItem, so DefaultMediaSourceFactory then creates the correct source
 * (HlsMediaSource / DashMediaSource / ...). Any failure (network error,
 * unknown type) falls back to the original MediaItem, i.e. exactly the old
 * stub behaviour, so nothing that played before can break.
 *
 * <p>Threading: createMediaSource is called on the thread that prepares the
 * player. The extra open() is one header-only request (the body is not read
 * unless the Content-Type is unhelpful, and then at most 256 bytes). For the
 * local proxy it is localhost and returns immediately. A slow remote server
 * delays playback start by the same request the player was about to make anyway.
 */
@UnstableApi
public final class ContentTypeResolvingMediaSource {

  public static final class Factory implements MediaSource.Factory {

    private final MediaSource.Factory factory;
    private final DataSource.Factory dataSourceFactory;

    public Factory(MediaSource.Factory factory, DataSource.Factory dataSourceFactory) {
      this.factory = factory;
      this.dataSourceFactory = dataSourceFactory;
    }

    @Override
    public MediaSource createMediaSource(MediaItem mediaItem) {
      MediaItem.LocalConfiguration config = mediaItem.localConfiguration;
      if (config == null || config.uri == null) return factory.createMediaSource(mediaItem);
      String mimeType = config.mimeType;
      if (mimeType != null && !mimeType.isEmpty()) return factory.createMediaSource(mediaItem);
      Uri uri = config.uri;
      // The extension already reveals the type (e.g. .m3u8 / .mp4): no network needed.
      if (Util.inferContentType(uri) != C.CONTENT_TYPE_OTHER) {
        return factory.createMediaSource(mediaItem);
      }
      // Extension-less and no MIME type: resolve from the response.
      String resolved = resolveMimeType(uri);
      if (resolved == null) return factory.createMediaSource(mediaItem);
      return factory.createMediaSource(
          mediaItem.buildUpon().setMimeType(resolved).build());
    }

    /**
     * Opens the URI once and determines its MIME type from the response
     * Content-Type, falling back to sniffing the first bytes. Returns null if
     * the type could not be determined.
     */
    @Nullable
    private String resolveMimeType(Uri uri) {
      String scheme = uri.getScheme();
      if (scheme == null
          || (!"http".equalsIgnoreCase(scheme) && !"https".equalsIgnoreCase(scheme))) {
        return null;
      }
      DataSource dataSource = null;
      try {
        dataSource = dataSourceFactory.createDataSource();
        dataSource.open(new DataSpec(uri));
        String resolved = mimeTypeFromHeaders(dataSource.getResponseHeaders());
        if (resolved != null) return resolved;
        return mimeTypeFromContent(dataSource);
      } catch (Exception e) {
        return null;
      } finally {
        if (dataSource != null) {
          try {
            dataSource.close();
          } catch (IOException ignored) {
            // Nothing to do: resolution already finished or failed.
          }
        }
      }
    }

    @Nullable
    private static String mimeTypeFromHeaders(@Nullable Map<String, List<String>> headers) {
      if (headers == null) return null;
      for (Map.Entry<String, List<String>> entry : headers.entrySet()) {
        if (!"Content-Type".equalsIgnoreCase(entry.getKey())) continue;
        for (String value : entry.getValue()) {
          String mime = mimeTypeFromContentType(value);
          if (mime != null) return mime;
        }
      }
      return null;
    }

    /** Maps a response Content-Type to a MIME type DefaultMediaSourceFactory understands. */
    @Nullable
    private static String mimeTypeFromContentType(@Nullable String contentType) {
      if (contentType == null) return null;
      String type = contentType.split(";", 2)[0].trim().toLowerCase();
      String normalized = MimeTypes.normalizeMimeType(type);
      if (MimeTypes.APPLICATION_M3U8.equals(normalized)
          || MimeTypes.APPLICATION_MPD.equals(normalized)
          || MimeTypes.APPLICATION_SS.equals(normalized)) {
        return normalized;
      }
      // Common server spellings for an HLS playlist / DASH manifest.
      if (type.contains("mpegurl") || "application/vnd.apple.mpegurl".equals(type)) {
        return MimeTypes.APPLICATION_M3U8;
      }
      if (type.contains("dash+xml")) return MimeTypes.APPLICATION_MPD;
      return null;
    }

    /** Sniffs the first bytes for an HLS playlist or DASH manifest marker. */
    @Nullable
    private static String mimeTypeFromContent(DataSource dataSource) {
      // 256 bytes is enough: "#EXTM3U" is at offset 0, and "<MPD" follows the
      // short "<?xml ...?>" declaration of a DASH manifest.
      byte[] buffer = new byte[256];
      int total = 0;
      try {
        while (total < buffer.length) {
          int read = dataSource.read(buffer, total, buffer.length - total);
          if (read == -1) break;
          total += read;
        }
      } catch (Exception ignored) {
        return null;
      }
      if (total <= 0) return null;
      String head = new String(buffer, 0, total, StandardCharsets.UTF_8);
      if (head.startsWith("#EXTM3U")) return MimeTypes.APPLICATION_M3U8;
      if (head.contains("<MPD")) return MimeTypes.APPLICATION_MPD;
      return null;
    }

    @Override
    public int[] getSupportedTypes() {
      return factory.getSupportedTypes();
    }

    @Override
    public Factory setDrmSessionManagerProvider(
        DrmSessionManagerProvider drmSessionManagerProvider) {
      factory.setDrmSessionManagerProvider(drmSessionManagerProvider);
      return this;
    }

    @Override
    public Factory setLoadErrorHandlingPolicy(LoadErrorHandlingPolicy loadErrorHandlingPolicy) {
      factory.setLoadErrorHandlingPolicy(loadErrorHandlingPolicy);
      return this;
    }
  }
}
