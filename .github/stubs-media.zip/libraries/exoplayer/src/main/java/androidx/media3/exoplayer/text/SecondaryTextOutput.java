package androidx.media3.exoplayer.text;

import androidx.annotation.Nullable;
import androidx.media3.common.text.CueGroup;

/**
 * 0.1.107：真实现（原为空壳，onCues 直接把第二路字幕丢掉）。
 *
 * <p>第二路 TextRenderer 的输出目标：原样把 cue 转给委托。委托由
 * LibassSubtitleController.setSecondaryTextOutput() 挂接，通常是第二路 SubtitleView
 * 的适配（见 LibassPlayerViewController）。没挂委托时 cue 被丢弃，不崩。
 */
public final class SecondaryTextOutput implements TextOutput {

  @Nullable private volatile TextOutput delegate;

  public SecondaryTextOutput() {}

  /** 挂接/解挂第二路字幕的输出目标（null 为解挂）。 */
  public void setTextOutput(@Nullable TextOutput textOutput) {
    this.delegate = textOutput;
  }

  @Override
  public void onCues(CueGroup cueGroup) {
    TextOutput output = delegate;
    if (output != null) output.onCues(cueGroup);
  }
}
