package androidx.media3.exoplayer.trackselection;

import android.content.Context;

import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.Timeline;
import androidx.media3.common.TrackGroup;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.audio.AudioAttributes;
import androidx.media3.exoplayer.ExoPlaybackException;
import androidx.media3.exoplayer.RendererCapabilities;
import androidx.media3.exoplayer.RendererConfiguration;
import androidx.media3.exoplayer.source.MediaSource.MediaPeriodId;
import androidx.media3.exoplayer.source.TrackGroupArray;
import androidx.media3.exoplayer.upstream.BandwidthMeter;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * 0.1.107：真实现（原为空壳 Factory，直接透传委托的选择器，第二路字幕永远选不上）。
 *
 * <p>包住委托选择器（通常是 DecodeTrackSelector）：委托照常选出主字幕后，
 * 本选择器再给第二个 text renderer 补一个选择：
 *
 * <ul>
 *   <li>用户在字幕菜单里指定了第二路（TrackSelectionOverride）时，用它；
 *   <li>没指定、且开了 AUTO 时，自动挑一条语言与主字幕不同的字幕轨；
 *   <li>都挑不到时，第二路 renderer 保持委托的结果（通常是禁用）。
 * </ul>
 *
 * <p>共享状态（当前 override、AUTO 开关、最近一次实际生效的第二路选择）存在 Factory 里，
 * 同一个 Factory 造出的所有选择器（播放器 + 预加载各一个）共用；状态一变就对所有已创建的
 * 选择器调 invalidate(null)，让播放器重新选轨。
 *
 * <p>已知局限：返回的 Tracks 对象是委托的原样（第二路选择不体现在里面）。
 * 字幕菜单的“主/副”标记不走 Tracks，走 LibassSubtitleController.getSubtitleSelectionState()
 * （主路从 player.getCurrentTracks() 读，副路读这里的 appliedSecondarySelection），
 * 所以菜单显示仍然正确。
 */
public final class SecondaryTextTrackSelector {

  public static final class Factory implements TrackSelector.Factory {

    private final TrackSelector.Factory factory;

    /** 用户指定的第二路选择（null = 未指定）。 */
    @Nullable private volatile TrackSelectionOverride secondaryOverride;

    /** AUTO 模式：没指定第二路时自动挑一条不同语言的字幕。 */
    private volatile boolean autoSelectionEnabled;

    /** 最近一次 selectTracks 实际生效的第二路选择（null = 当前没第二路）。 */
    @Nullable private volatile TrackSelectionOverride appliedSecondarySelection;

    private final List<SecondaryTextTrackSelector> selectors = new ArrayList<>();

    public Factory(TrackSelector.Factory factory) {
      this.factory = factory;
    }

    @Override
    public TrackSelector createTrackSelector(Context context) {
      SecondaryTextTrackSelector selector =
          new SecondaryTextTrackSelector(factory.createTrackSelector(context), this);
      synchronized (selectors) {
        selectors.add(selector);
      }
      return selector;
    }

    /** 用户指定/清除第二路选择（TrackDialog / 恢复保存的选择时调用）。 */
    public void setSecondaryTextTrackSelectionOverride(
        @Nullable TrackSelectionOverride selection) {
      secondaryOverride = selection;
      invalidateAll();
    }

    /** 开/关 AUTO 自动挑第二路（SubtitleSetting.SECONDARY_MODE_AUTO）。 */
    public void setSecondaryTextTrackAutoSelectionEnabled(boolean enabled) {
      autoSelectionEnabled = enabled;
      invalidateAll();
    }

    /** 最近一次实际生效的第二路选择，供 LibassSubtitleController 拼状态用。 */
    @Nullable
    public TrackSelectionOverride getAppliedSecondarySelection() {
      return appliedSecondarySelection;
    }

    private void invalidateAll() {
      List<SecondaryTextTrackSelector> copy;
      synchronized (selectors) {
        copy = new ArrayList<>(selectors);
      }
      for (SecondaryTextTrackSelector selector : copy) {
        selector.invalidate(null);
      }
    }
  }

  private final TrackSelector delegate;
  private final Factory factory;

  private SecondaryTextTrackSelector(TrackSelector delegate, Factory factory) {
    this.delegate = delegate;
    this.factory = factory;
  }

  @Override
  public TrackSelectorResult selectTracks(
      RendererCapabilities[] rendererCapabilities,
      TrackGroupArray trackGroups,
      MediaPeriodId periodId,
      Timeline timeline)
      throws ExoPlaybackException {
    TrackSelectorResult result =
        delegate.selectTracks(rendererCapabilities, trackGroups, periodId, timeline);

    int primaryTextIndex = -1;
    int secondaryTextIndex = -1;
    for (int i = 0; i < rendererCapabilities.length; i++) {
      if (rendererCapabilities[i].getTrackType() == C.TRACK_TYPE_TEXT) {
        if (primaryTextIndex < 0) {
          primaryTextIndex = i;
        } else if (secondaryTextIndex < 0) {
          secondaryTextIndex = i;
        }
      }
    }
    if (secondaryTextIndex < 0) {
      factory.appliedSecondarySelection = null;
      return result;
    }

    TrackSelectionOverride secondary =
        resolveSecondary(rendererCapabilities, trackGroups, result, primaryTextIndex);
    if (secondary == null) {
      factory.appliedSecondarySelection = null;
      return result;
    }

    ExoTrackSelection[] selections = result.selections.clone();
    RendererConfiguration[] configurations = result.rendererConfigurations.clone();
    selections[secondaryTextIndex] =
        new FixedTrackSelection(
            secondary.mediaTrackGroup, secondary.trackIndices.get(0));
    if (configurations[secondaryTextIndex] == null) {
      configurations[secondaryTextIndex] = RendererConfiguration.DEFAULT;
    }
    factory.appliedSecondarySelection = secondary;
    return new TrackSelectorResult(configurations, selections, result.tracks, result.info);
  }

  @Override
  public void onSelectionActivated(@Nullable Object info) {
    delegate.onSelectionActivated(info);
  }

  @Override
  public void onParametersActivated(@Nullable TrackSelectionParameters parameters) {
    delegate.onParametersActivated(parameters);
  }

  @Override
  public TrackSelectionParameters getParameters() {
    return delegate.getParameters();
  }

  @Override
  public void setParameters(TrackSelectionParameters parameters) {
    delegate.setParameters(parameters);
  }

  @Override
  public boolean isSetParametersSupported() {
    return delegate.isSetParametersSupported();
  }

  @Override
  public void setAudioAttributes(AudioAttributes audioAttributes) {
    delegate.setAudioAttributes(audioAttributes);
  }

  @Override
  @Nullable
  public RendererCapabilities.Listener getRendererCapabilitiesListener() {
    return delegate.getRendererCapabilitiesListener();
  }

  @Override
  public void init(InvalidationListener listener, BandwidthMeter bandwidthMeter) {
    delegate.init(listener, bandwidthMeter);
  }

  @Override
  public void release() {
    delegate.release();
  }

  /**
   * 决定本轮的第二路选择。指定了 override 且它还在当前 TrackGroupArray 里（按值匹配，
   * 因为换集后 group 实例会变）就用它；否则 AUTO 开着时挑一条语言与主字幕不同的轨。
   * 字幕轨的判定走主字幕 renderer 的 supportsFormat（字幕 mime 种类多，text/ 前缀会漏掉
   * application/x-subrip、application/ttml+xml 等）。
   */
  @Nullable
  private TrackSelectionOverride resolveSecondary(
      RendererCapabilities[] rendererCapabilities,
      TrackGroupArray trackGroups,
      TrackSelectorResult result,
      int primaryTextIndex) {
    TrackSelectionOverride override = factory.secondaryOverride;
    if (override != null) {
      TrackGroup matched = findGroup(trackGroups, override.mediaTrackGroup);
      if (matched != null && !override.trackIndices.isEmpty()) {
        int index = override.trackIndices.get(0);
        if (index < matched.length && !isSameAsPrimary(result, primaryTextIndex, matched, index)) {
          return new TrackSelectionOverride(matched, index);
        }
      }
      return null;
    }
    if (!factory.autoSelectionEnabled || primaryTextIndex < 0) return null;
    ExoTrackSelection primary = result.selections[primaryTextIndex];
    if (primary == null) return null;
    String primaryLanguage = primary.getSelectedFormat().language;
    RendererCapabilities textCapabilities = rendererCapabilities[primaryTextIndex];
    for (int g = 0; g < trackGroups.length; g++) {
      TrackGroup group = trackGroups.get(g);
      for (int i = 0; i < group.length; i++) {
        Format format = group.getFormat(i);
        if (textCapabilities.supportsFormat(format) != RendererCapabilities.FORMAT_HANDLED) {
          continue;
        }
        if (Objects.equals(format.language, primaryLanguage)) continue;
        if (isSameAsPrimary(result, primaryTextIndex, group, i)) continue;
        return new TrackSelectionOverride(group, i);
      }
    }
    return null;
  }

  /** 按值找 group（TrackGroup.equals 按格式数组比较，换集后实例不同但值相同）。 */
  @Nullable
  private static TrackGroup findGroup(TrackGroupArray trackGroups, TrackGroup group) {
    for (int i = 0; i < trackGroups.length; i++) {
      if (trackGroups.get(i).equals(group)) return trackGroups.get(i);
    }
    return null;
  }

  /** 这条轨是不是主字幕正在用的那条（避免主副选同一条）。 */
  private static boolean isSameAsPrimary(
      TrackSelectorResult result, int primaryTextIndex, TrackGroup group, int index) {
    if (primaryTextIndex < 0) return false;
    ExoTrackSelection primary = result.selections[primaryTextIndex];
    if (primary == null) return false;
    return primary.getTrackGroup().equals(group) && primary.getSelectedIndex() == index;
  }
}
