package androidx.media3.exoplayer.libass;

import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.Tracks;
import androidx.media3.common.text.SubtitleSelectionState;
import androidx.media3.exoplayer.text.SecondaryTextOutput;
import androidx.media3.exoplayer.text.TextOutput;
import androidx.media3.exoplayer.trackselection.SecondaryTextTrackSelector;

/**
 * 0.1.107：真实现（原为空壳，getSubtitleSelectionState 恒返回 EMPTY，第二路选择全是 no-op，
 * 所以双字幕的菜单标记和选择都走不通）。
 *
 * <p>主路选择从 player.getCurrentTracks() 读（委托选择器只会把主字幕标为已选，
 * 第二路不在 Tracks 里体现）；副路选择读 SecondaryTextTrackSelector.Factory 里
 * 最近一次实际生效的那个。两者拼成 SubtitleSelectionState，供字幕菜单、字幕偏移面板用。
 */
public final class LibassSubtitleController {

  private final Player player;
  private final LibassPlaybackSession libassPlaybackSession;
  private final SecondaryTextTrackSelector.Factory secondaryTextTrackSelectorFactory;
  private final SecondaryTextOutput secondaryTextOutput;

  public LibassSubtitleController(
      Player player,
      LibassPlaybackSession libassPlaybackSession,
      SecondaryTextTrackSelector.Factory secondaryTextTrackSelectorFactory,
      SecondaryTextOutput secondaryTextOutput) {
    this.player = player;
    this.libassPlaybackSession = libassPlaybackSession;
    this.secondaryTextTrackSelectorFactory = secondaryTextTrackSelectorFactory;
    this.secondaryTextOutput = secondaryTextOutput;
  }

  public SubtitleSelectionState getSubtitleSelectionState() {
    TrackSelectionOverride primary = null;
    Tracks tracks = player.getCurrentTracks();
    outer:
    for (Tracks.Group group : tracks.getGroups()) {
      if (group.getType() != C.TRACK_TYPE_TEXT) continue;
      for (int i = 0; i < group.length; i++) {
        if (group.isTrackSelected(i)) {
          primary = new TrackSelectionOverride(group.getMediaTrackGroup(), i);
          break outer;
        }
      }
    }
    TrackSelectionOverride secondary =
        secondaryTextTrackSelectorFactory.getAppliedSecondarySelection();
    if (secondary != null && secondary.equals(primary)) secondary = null;
    return new SubtitleSelectionState(primary, secondary);
  }

  public void setSecondaryTextTrackSelectionOverride(
      @Nullable TrackSelectionOverride selection) {
    secondaryTextTrackSelectorFactory.setSecondaryTextTrackSelectionOverride(selection);
  }

  public void setSecondaryTextTrackAutoSelectionEnabled(boolean enabled) {
    secondaryTextTrackSelectorFactory.setSecondaryTextTrackAutoSelectionEnabled(enabled);
  }

  /**
   * 挂接第二路字幕的输出目标（LibassPlayerViewController 在建好第二路 SubtitleView 后调用，
   * 传一个把 CueGroup 转给 SubtitleView.setCues 的适配；传 null 为解挂）。
   */
  public void setSecondaryTextOutput(@Nullable TextOutput textOutput) {
    secondaryTextOutput.setTextOutput(textOutput);
  }

  public void close() {
    secondaryTextOutput.setTextOutput(null);
  }
}
