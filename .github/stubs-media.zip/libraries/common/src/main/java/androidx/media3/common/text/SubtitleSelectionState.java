package androidx.media3.common.text;

import androidx.annotation.Nullable;
import androidx.media3.common.TrackSelectionOverride;
import java.util.Objects;

public final class SubtitleSelectionState {

  public static final SubtitleSelectionState EMPTY = new SubtitleSelectionState(null, null);

  @Nullable public final TrackSelectionOverride primarySelection;
  @Nullable public final TrackSelectionOverride activeSecondarySelection;

  public SubtitleSelectionState(
      @Nullable TrackSelectionOverride primarySelection,
      @Nullable TrackSelectionOverride activeSecondarySelection) {
    this.primarySelection = primarySelection;
    this.activeSecondarySelection = activeSecondarySelection;
  }

  public boolean isPrimary(@Nullable TrackSelectionOverride selection) {
    return Objects.equals(selection, primarySelection);
  }

  public boolean isActiveSecondary(@Nullable TrackSelectionOverride selection) {
    return Objects.equals(selection, activeSecondarySelection);
  }

  // 0.1.107：值相等。LibassSubtitleController 每次返回新对象，字幕偏移面板用
  // selection.equals(player.getSubtitleSelectionState()) 比较状态；没有值相等时
  // 那个比较永远为假（原来恒返回 EMPTY 常量时靠同一实例才碰巧成立）。
  @Override
  public boolean equals(Object obj) {
    if (this == obj) return true;
    if (!(obj instanceof SubtitleSelectionState)) return false;
    SubtitleSelectionState other = (SubtitleSelectionState) obj;
    return Objects.equals(primarySelection, other.primarySelection)
        && Objects.equals(activeSecondarySelection, other.activeSecondarySelection);
  }

  @Override
  public int hashCode() {
    return Objects.hash(primarySelection, activeSecondarySelection);
  }
}
