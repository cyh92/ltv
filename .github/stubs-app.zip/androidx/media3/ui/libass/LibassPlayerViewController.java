package androidx.media3.ui.libass;

import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.libass.LibassPlaybackSession;
import androidx.media3.exoplayer.libass.LibassSubtitleController;
import androidx.media3.ui.CaptionStyleCompat;
import androidx.media3.ui.PlayerView;
import androidx.media3.ui.SubtitleView;

import java.util.function.Consumer;

/**
 * 0.1.107：真实现（原为空壳，第二路 SubtitleView 从来没被建出来，双字幕无处可画）。
 *
 * <p>bind 时在 PlayerView 里主字幕 view 紧后方插一个第二路 SubtitleView
 * （与主路同尺寸的覆盖层；上下位置由 configurator 通过 setBottomPosition 定，
 * 见 ExoSubtitleController.applySecondarySubtitleStyle），
 * 并把它的 cue 输入挂到 LibassSubtitleController 上。样式覆盖只作用于主路 view
 * （fontFamily 已包含在 CaptionStyleCompat 的 typeface 里，见 SubtitleSetting.getStyle()；
 * 第二路的样式由 configurator 单独处理）。
 */
public final class LibassPlayerViewController {

  private final Player player;
  private final LibassPlaybackSession libassPlaybackSession;
  private final LibassSubtitleController libassSubtitleController;

  @Nullable private PlayerView playerView;
  @Nullable private SubtitleView secondarySubtitleView;
  @Nullable private Consumer<SubtitleView> secondarySubtitleViewConfigurator;
  @Nullable private CaptionStyleCompat styleOverride;
  @Nullable private String fontFamily;

  public LibassPlayerViewController(
      Player player,
      LibassPlaybackSession libassPlaybackSession,
      LibassSubtitleController libassSubtitleController) {
    this.player = player;
    this.libassPlaybackSession = libassPlaybackSession;
    this.libassSubtitleController = libassSubtitleController;
  }

  public void bind(PlayerView playerView) {
    this.playerView = playerView;
    removeSecondarySubtitleView();
    SubtitleView primary = playerView.getSubtitleView();
    if (primary == null) return;
    ViewGroup parent = (ViewGroup) primary.getParent();
    if (parent == null) return;
    secondarySubtitleView = new SubtitleView(playerView.getContext());
    parent.addView(
        secondarySubtitleView, parent.indexOfChild(primary) + 1, primary.getLayoutParams());
    if (secondarySubtitleViewConfigurator != null) {
      secondarySubtitleViewConfigurator.accept(secondarySubtitleView);
    }
    if (styleOverride != null) {
      secondarySubtitleView.setStyle(styleOverride);
    }
    libassSubtitleController.setSecondaryTextOutput(
        cueGroup -> secondarySubtitleView.setCues(cueGroup.cues));
  }

  public void setStyleOverride(@Nullable CaptionStyleCompat style, @Nullable String fontFamily) {
    this.styleOverride = style;
    this.fontFamily = fontFamily;
    if (playerView != null) {
      SubtitleView primary = playerView.getSubtitleView();
      if (primary != null && style != null) primary.setStyle(style);
    }
  }

  public void setSecondarySubtitleViewConfigurator(Consumer<SubtitleView> configurator) {
    this.secondarySubtitleViewConfigurator = configurator;
    if (secondarySubtitleView != null) configurator.accept(secondarySubtitleView);
  }

  public void close() {
    libassSubtitleController.setSecondaryTextOutput(null);
    removeSecondarySubtitleView();
    playerView = null;
  }

  private void removeSecondarySubtitleView() {
    if (secondarySubtitleView != null && secondarySubtitleView.getParent() instanceof ViewGroup) {
      ((ViewGroup) secondarySubtitleView.getParent()).removeView(secondarySubtitleView);
    }
    secondarySubtitleView = null;
  }
}
